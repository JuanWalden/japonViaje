import React, { useState, useEffect } from 'react';
import { Check, MapPin, Calendar, ShoppingCart, Settings, Sun, Moon, Wallet, Plane, Clock, Star, ExternalLink, Camera, Navigation, Wifi, WifiOff, CloudRain, Cloud, CloudSnow, Thermometer, Shirt } from 'lucide-react';

interface VisitedPlace {
  [key: string]: boolean;
}

interface Note {
  [key: string]: string;
}

interface PurchaseItem {
  id: string;
  name: string;
  category: string;
  estimated_price: number;
  purchased: boolean;
  actual_price?: number;
  location?: string;
  notes?: string;
}

interface BudgetCategory {
  id: string;
  name: string;
  budgeted: number;
  spent: number;
  color: string;
}

interface WeatherData {
  temp: number;
  condition: string;
  icon: string;
  humidity: number;
  windSpeed: number;
  clothingSuggestion: string;
  clothingIcon: string;
}

interface CityWeather {
  [key: string]: WeatherData;
}

function App() {
  const [activeTab, setActiveTab] = useState('itinerary');
  const [darkMode, setDarkMode] = useState(false);
  const [visitedPlaces, setVisitedPlaces] = useState<VisitedPlace>({});
  const [notes, setNotes] = useState<Note>({});
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [currentWeather, setCurrentWeather] = useState<CityWeather | null>(null);
  const [japanTime, setJapanTime] = useState<string>('');
  const [spainTime, setSpainTime] = useState<string>('');
  const [weatherLoading, setWeatherLoading] = useState(true);
  const [purchaseList, setPurchaseList] = useState<PurchaseItem[]>([]);
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState('Souvenirs');
  const [newItemPrice, setNewItemPrice] = useState('');
  const [budgetCategories, setBudgetCategories] = useState<BudgetCategory[]>([
    { id: 'food', name: 'Comida y bebida', budgeted: 80000, spent: 0, color: 'from-orange-500 to-red-500' },
    { id: 'shopping', name: 'Compras y souvenirs', budgeted: 60000, spent: 0, color: 'from-purple-500 to-pink-500' },
    { id: 'transport', name: 'Transporte local', budgeted: 40000, spent: 0, color: 'from-blue-500 to-cyan-500' },
    { id: 'activities', name: 'Actividades y entradas', budgeted: 30000, spent: 0, color: 'from-green-500 to-teal-500' },
    { id: 'misc', name: 'Varios y emergencias', budgeted: 20000, spent: 0, color: 'from-gray-500 to-slate-500' }
  ]);
  const [yenAmount, setYenAmount] = useState('1000');
  const [euroAmount, setEuroAmount] = useState('6.67');
  const exchangeRate = 150; // 1 EUR = 150 JPY aproximadamente

  const tripStartDate = new Date('2025-09-16');
  const tripEndDate = new Date('2025-10-01');
  const today = new Date();
  const daysUntilTrip = Math.max(0, Math.ceil((tripStartDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)));
  const daysInTrip = Math.ceil((tripEndDate.getTime() - tripStartDate.getTime()) / (1000 * 60 * 60 * 24));

  useEffect(() => {
    // Load saved data from localStorage
    const savedVisitedPlaces = localStorage.getItem('japan-visited-places');
    const savedNotes = localStorage.getItem('japan-notes');
    const savedPurchaseList = localStorage.getItem('japan-purchase-list');
    const savedBudgetCategories = localStorage.getItem('japan-budget-categories');
    
    if (savedVisitedPlaces) {
      setVisitedPlaces(JSON.parse(savedVisitedPlaces));
    }
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
    if (savedPurchaseList) {
      setPurchaseList(JSON.parse(savedPurchaseList));
    }
    if (savedBudgetCategories) {
      setBudgetCategories(JSON.parse(savedBudgetCategories));
    }
    
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Save data to localStorage whenever state changes
  useEffect(() => {
    localStorage.setItem('japan-visited-places', JSON.stringify(visitedPlaces));
  }, [visitedPlaces]);

  useEffect(() => {
    localStorage.setItem('japan-notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    localStorage.setItem('japan-purchase-list', JSON.stringify(purchaseList));
  }, [purchaseList]);

  useEffect(() => {
    localStorage.setItem('japan-budget-categories', JSON.stringify(budgetCategories));
  }, [budgetCategories]);

  useEffect(() => {
    // Función para obtener sugerencia de ropa basada en temperatura
    const getClothingSuggestion = (temp: number): { suggestion: string; icon: string } => {
      if (temp < 5) return { suggestion: 'Abrigo grueso, guantes, gorro', icon: '🧥' };
      if (temp < 10) return { suggestion: 'Chaqueta de invierno, bufanda', icon: '🧣' };
      if (temp < 15) return { suggestion: 'Chaqueta ligera, suéter', icon: '🧥' };
      if (temp < 20) return { suggestion: 'Suéter o cardigan', icon: '👕' };
      if (temp < 25) return { suggestion: 'Camiseta manga larga', icon: '👔' };
      if (temp < 30) return { suggestion: 'Camiseta, ropa ligera', icon: '👕' };
      return { suggestion: 'Ropa muy ligera, protector solar', icon: '🩱' };
    };

    // Función para actualizar la hora de Japón
    const updateJapanTime = () => {
      const now = new Date();
      const japanTime = new Date(now.toLocaleString("en-US", {timeZone: "Asia/Tokyo"}));
      const timeString = japanTime.toLocaleString('es-ES', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Asia/Tokyo'
      });
      setJapanTime(timeString);
    };

    // Función para actualizar la hora de España
    const updateSpainTime = () => {
      const now = new Date();
      const spainTime = new Date(now.toLocaleString("en-US", {timeZone: "Europe/Madrid"}));
      const timeString = spainTime.toLocaleString('es-ES', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
        timeZone: 'Europe/Madrid'
      });
      setSpainTime(timeString);
    };

    // Función para obtener datos meteorológicos simulados realistas
    const fetchWeatherData = async () => {
      setWeatherLoading(true);
      
      // Datos realistas para enero en Japón (invierno)
      const baseTemps = {
        tokyo: 8 + Math.random() * 6 - 2, // 6-12°C (invierno en Tokyo)
        kyoto: 6 + Math.random() * 6 - 2, // 4-10°C (más frío en Kyoto)
        takayama: 2 + Math.random() * 6 - 2, // 0-6°C (montañoso, más frío)
        osaka: 9 + Math.random() * 6 - 2 // 7-13°C (similar a Tokyo)
      };

      // Condiciones típicas de invierno en Japón
      const conditions = ['Soleado y frío', 'Parcialmente nublado', 'Nublado', 'Posible nieve', 'Despejado'];
      const icons = ['☀️', '⛅', '☁️', '❄️', '🌤️'];
      
      const weatherData: CityWeather = {};
      
      Object.entries(baseTemps).forEach(([city, temp]) => {
        const conditionIndex = Math.floor(Math.random() * conditions.length);
        const clothing = getClothingSuggestion(temp);
        
        weatherData[city] = {
          temp: Math.round(temp),
          condition: conditions[conditionIndex],
          icon: icons[conditionIndex],
          humidity: 60 + Math.random() * 20, // 60-80%
          windSpeed: Math.round(5 + Math.random() * 10), // 5-15 km/h
          clothingSuggestion: clothing.suggestion,
          clothingIcon: clothing.icon
        };
      });

      try {
        // Coordenadas de las ciudades japonesas
        const cities = {
          tokyo: { lat: 35.6762, lon: 139.6503 },
          kyoto: { lat: 35.0116, lon: 135.7681 },
          takayama: { lat: 36.1397, lon: 137.2531 },
          osaka: { lat: 34.6937, lon: 135.5023 }
        };

        const weatherData: CityWeather = {};
        
        // Obtener datos reales para cada ciudad usando OpenWeatherMap API gratuita
        for (const [cityName, coords] of Object.entries(cities)) {
          try {
            // Usamos la API gratuita de OpenWeatherMap (sin necesidad de API key para datos básicos)
            const response = await fetch(
              `https://api.openweathermap.org/data/2.5/weather?lat=${coords.lat}&lon=${coords.lon}&appid=demo&units=metric&lang=es`,
              { 
                method: 'GET',
                headers: {
                  'Accept': 'application/json',
                }
              }
            );
            
            if (response.ok) {
              const data = await response.json();
              const temp = Math.round(data.main.temp);
              const clothing = getClothingSuggestion(temp);
              
              // Mapear códigos de clima a iconos y descripciones
              const getWeatherIcon = (code: string) => {
                if (code.includes('01')) return '☀️';
                if (code.includes('02')) return '⛅';
                if (code.includes('03') || code.includes('04')) return '☁️';
                if (code.includes('09') || code.includes('10')) return '🌦️';
                if (code.includes('11')) return '⛈️';
                if (code.includes('13')) return '❄️';
                if (code.includes('50')) return '🌫️';
                return '🌤️';
              };
              
              weatherData[cityName] = {
                temp: temp,
                condition: data.weather[0].description,
                icon: getWeatherIcon(data.weather[0].icon),
                humidity: data.main.humidity,
                windSpeed: Math.round(data.wind?.speed * 3.6) || 0, // m/s a km/h
                clothingSuggestion: clothing.suggestion,
                clothingIcon: clothing.icon
              };
            } else {
              throw new Error('API response not ok');
            }
          } catch (error) {
            console.log(`Error fetching weather for ${cityName}, using fallback data`);
            // Datos de respaldo más realistas para enero en Japón
            const fallbackTemps = {
              tokyo: 8,
              kyoto: 6,
              takayama: 2,
              osaka: 9
            };
            
            const temp = fallbackTemps[cityName as keyof typeof fallbackTemps];
            const clothing = getClothingSuggestion(temp);
            
            weatherData[cityName] = {
              temp: temp,
              condition: 'Datos no disponibles',
              icon: '🌤️',
              humidity: 65,
              windSpeed: 8,
              clothingSuggestion: clothing.suggestion,
              clothingIcon: clothing.icon
            };
          }
        }
        
        setCurrentWeather(weatherData);
      } catch (error) {
        console.error('Error general fetching weather:', error);
        // Datos de respaldo para enero
        const fallbackData: CityWeather = {
          tokyo: { temp: 8, condition: 'Frío invernal', icon: '🌤️', humidity: 65, windSpeed: 8, clothingSuggestion: 'Chaqueta de invierno, bufanda', clothingIcon: '🧣' },
          kyoto: { temp: 6, condition: 'Frío invernal', icon: '☁️', humidity: 70, windSpeed: 6, clothingSuggestion: 'Chaqueta de invierno, bufanda', clothingIcon: '🧣' },
          takayama: { temp: 2, condition: 'Muy frío', icon: '❄️', humidity: 75, windSpeed: 10, clothingSuggestion: 'Abrigo grueso, guantes, gorro', clothingIcon: '🧥' },
          osaka: { temp: 9, condition: 'Frío invernal', icon: '🌤️', humidity: 68, windSpeed: 7, clothingSuggestion: 'Chaqueta de invierno, bufanda', clothingIcon: '🧣' }
        };
        setCurrentWeather(fallbackData);
      }
      
      setWeatherLoading(false);
    };

    // Cargar datos iniciales
    fetchWeatherData();
    updateJapanTime();
    updateSpainTime();

    // Actualizar hora cada minuto
    const timeInterval = setInterval(() => {
      updateJapanTime();
      updateSpainTime();
    }, 60000);
    
    // Actualizar clima cada 10 minutos para datos más frescos
    const weatherInterval = setInterval(fetchWeatherData, 10 * 60 * 1000);

    return () => {
      clearInterval(timeInterval);
      clearInterval(weatherInterval);
    };
  }, []);

  const togglePlace = (placeId: string) => {
    setVisitedPlaces(prev => ({
      ...prev,
      [placeId]: !prev[placeId]
    }));
  };

  const updateNote = (noteId: string, content: string) => {
    setNotes(prev => ({
      ...prev,
      [noteId]: content
    }));
  };

  const togglePurchase = (itemId: string) => {
    setPurchaseList(prev => prev.map(item => 
      item.id === itemId ? { ...item, purchased: !item.purchased } : item
    ));
  };

  const addNewItem = () => {
    if (newItemName.trim() && newItemPrice) {
      const newItem: PurchaseItem = {
        id: Date.now().toString(),
        name: newItemName.trim(),
        category: newItemCategory,
        estimated_price: parseInt(newItemPrice),
        purchased: false
      };
      setPurchaseList(prev => [...prev, newItem]);
      setNewItemName('');
      setNewItemPrice('');
    }
  };

  const removeItem = (itemId: string) => {
    setPurchaseList(prev => prev.filter(item => item.id !== itemId));
  };

  const updateItemPrice = (itemId: string, actualPrice: number) => {
    setPurchaseList(prev => prev.map(item => 
      item.id === itemId ? { ...item, actual_price: actualPrice } : item
    ));
  };

  const updateBudgetSpent = (categoryId: string, amount: number) => {
    setBudgetCategories(prev => prev.map(cat => 
      cat.id === categoryId ? { ...cat, spent: Math.max(0, cat.spent + amount) } : cat
    ));
  };

  const convertYenToEuro = (yen: string) => {
    const yenValue = parseFloat(yen) || 0;
    const euroValue = (yenValue / exchangeRate).toFixed(2);
    setYenAmount(yen);
    setEuroAmount(euroValue);
  };

  const convertEuroToYen = (euro: string) => {
    const euroValue = parseFloat(euro) || 0;
    const yenValue = Math.round(euroValue * exchangeRate).toString();
    setEuroAmount(euro);
    setYenAmount(yenValue);
  };

  const totalBudget = budgetCategories.reduce((sum, cat) => sum + cat.budgeted, 0);
  const totalSpent = budgetCategories.reduce((sum, cat) => sum + cat.spent, 0);
  const shoppingBudget = purchaseList.reduce((sum, item) => sum + item.estimated_price, 0);
  const shoppingSpent = purchaseList.filter(item => item.purchased).reduce((sum, item) => sum + (item.actual_price || item.estimated_price), 0);

  const cities = [
    {
      name: 'Tokyo',
      dates: '17-20 & 29 sep - 1 oct',
      hotel: 'Quintessa Hotel Tokyo Ginza & Hilton Tokyo Shinjuku',
      hotelUrl: 'https://www.google.com/maps/search/?api=1&query=Quintessa+Hotel+Tokyo+Ginza',
      weather: currentWeather?.tokyo,
      color: 'from-red-500 to-pink-500'
    },
    {
      name: 'Kyoto',
      dates: '22-24 sep',
      hotel: 'TSUGU Kyoto Sanjo',
      hotelUrl: 'https://www.google.com/maps/search/?api=1&query=TSUGU+Kyoto+Sanjo',
      weather: currentWeather?.kyoto,
      color: 'from-purple-500 to-indigo-500'
    },
    {
      name: 'Takayama',
      dates: '24-26 sep',
      hotel: 'Ichinomatsu Japanese Modern Hotel',
      hotelUrl: 'https://www.google.com/maps/search/?api=1&query=Ichinomatsu+Japanese+Modern+Hotel+Takayama',
      weather: currentWeather?.takayama,
      color: 'from-green-500 to-teal-500'
    },
    {
      name: 'Osaka',
      dates: '27-29 sep',
      hotel: 'Sotetsu Fresa Inn Yodoyabashi',
      hotelUrl: 'https://www.google.com/maps/search/?api=1&query=Sotetsu+Fresa+Inn+Yodoyabashi+Osaka',
      weather: currentWeather?.osaka,
      color: 'from-orange-500 to-red-500'
    }
  ];

  const itineraryDays = [
    {
      id: 'day1',
      date: 'Mar 16',
      title: 'Llegada (NRT 17:30)',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Narita+Airport+Tokyo',
      activities: [
        'Llegada y traslado a Tokio',
        'Paseo ligero por la zona del hotel',
        { text: 'Cena sencilla (ramen o izakaya en Yūrakuchō Gado-shita)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Yurakucho+Gado-shita+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day2',
      date: 'Mié 17',
      title: 'Ginza esencial',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Ginza+Tokyo',
      activities: [
        { text: 'Ginza Itoya (papelería icónica, 12 plantas)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Ginza+Itoya+Tokyo' },
        { text: 'MUJI Ginza (flagship con hotel y food hall)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=MUJI+Ginza+Tokyo' },
        { text: 'UNIQLO Ginza (12F, básicos)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=UNIQLO+Ginza+Tokyo' },
        { text: 'Azotea y galería gratuitas de Kabukiza', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kabukiza+Theatre+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day3',
      date: 'Jue 18',
      title: 'Tsukiji + Hamarikyu + Asakusa & Kappabashi',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Tsukiji+Outer+Market+Tokyo',
      activities: [
        { text: 'Desayuno en Tsukiji Outer Market', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Tsukiji+Outer+Market+Tokyo' },
        { text: 'Té matcha en la casa de té de Jardines Hamarikyu', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Hamarikyu+Gardens+Tokyo' },
        'Crucero opcional a Asakusa',
        { text: 'Kappabashi (Kitchen Town) para menaje profesional y fake food', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kappabashi+Kitchen+Town+Tokyo' },
        { text: 'Atardecer en Senso-ji', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Senso-ji+Temple+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day4',
      date: 'Vie 19',
      title: 'Arte inmersivo u opción Roppongi',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=teamLab+Borderless+Tokyo',
      activities: [
        { text: 'teamLab Borderless (Azabudai Hills) — reservar con antelación', mapUrl: 'https://www.google.com/maps/search/?api=1&query=teamLab+Borderless+Azabudai+Hills+Tokyo' },
        { text: 'Alternativa: Mori Art Museum + mirador', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Mori+Art+Museum+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day5',
      date: 'Sáb 20',
      title: 'Shinjuku creativo',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Shinjuku+Tokyo',
      activities: [
        { text: 'SEKAIDO Shinjuku (arte, marcos, scrap & craft)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sekaido+Shinjuku+Tokyo' },
        { text: 'Jardín Shinjuku Gyoen (si no es lunes)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Shinjuku+Gyoen+National+Garden+Tokyo' },
        { text: 'Omoide Yokocho o Golden Gai por la noche', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Omoide+Yokocho+Shinjuku+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day6',
      date: 'Dom 21',
      title: 'Tendencias y vintage',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Harajuku+Tokyo',
      activities: [
        { text: 'Harajuku → Omotesandō → Daikanyama → Shimokitazawa (tiendas vintage)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Harajuku+Station+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day7',
      date: 'Lun 22',
      title: 'Llegada a Kyoto y "Kyoto\'s Kitchen"',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Nishiki+Market+Kyoto',
      activities: [
        'Check-in y paseo por Nishiki Market (pica-pica)',
        { text: 'Tiendas de telas y craft: Nomura Tailor y Yuzawaya', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Nomura+Tailor+Kyoto' },
        { text: 'Teramachi/Kawaramachi', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Teramachi+Shopping+District+Kyoto' },
        { text: 'Cena en Pontochō', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Pontocho+Alley+Kyoto' }
      ],
      city: 'Kyoto'
    },
    {
      id: 'day8',
      date: 'Mar 23 (festivo)',
      title: 'Fushimi Inari al alba + Higashiyama',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Fushimi+Inari+Shrine+Kyoto',
      activities: [
        { text: 'Fushimi Inari muy temprano (abierto 24h)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Fushimi+Inari+Shrine+Kyoto' },
        { text: 'Kiyomizu-dera → Sannenzaka/Ninenzaka', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kiyomizu-dera+Temple+Kyoto' },
        { text: 'Yasaka-jinja y Gion', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Yasaka+Shrine+Kyoto' }
      ],
      city: 'Kyoto'
    },
    {
      id: 'day9',
      date: 'Mié 24',
      title: 'Hacia Takayama',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Takayama+Japan',
      activities: [
        'Mañana libre (compras de última hora en Nishiki)',
        'Traslado a Takayama (JR o bus)',
        { text: 'Tarde: paseo por Sanmachi Suji', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sanmachi+Suji+Takayama' }
      ],
      city: 'Takayama'
    },
    {
      id: 'day10',
      date: 'Jue 25',
      title: 'Casco histórico + Jinya',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Takayama+Jinya+Japan',
      activities: [
        { text: 'Mercadillos matinales (Miyagawa/Jinya)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Miyagawa+Morning+Market+Takayama' },
        { text: 'Takayama Jinya', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Takayama+Jinya+Japan' },
        'Degustación de sake en bodegas locales',
        'Atardecer en puentes y casas tradicionales'
      ],
      city: 'Takayama'
    },
    {
      id: 'day11',
      date: 'Vie 26',
      title: 'Excursión a Shirakawa-go',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Shirakawa-go+Japan',
      activities: [
        { text: 'Bus Nōhi desde Takayama (≈50 min)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Takayama+Nohi+Bus+Center' },
        { text: 'Paseo por el pueblo gasshō y mirador', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Shirakawa-go+Historic+Village' },
        'Regreso para cena en Takayama'
      ],
      city: 'Takayama'
    },
    {
      id: 'day12',
      date: 'Sáb 27',
      title: 'Dōtonbori + Kuromon',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Dotonbori+Osaka',
      activities: [
        { text: 'Paseo y street food en Dōtonbori', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Dotonbori+Osaka' },
        { text: 'Kuromon Market (mejor 9–16 h)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kuromon+Ichiba+Market+Osaka' },
        { text: 'Doguyasuji (menaje)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Doguyasuji+Shotengai+Osaka' }
      ],
      city: 'Osaka'
    },
    {
      id: 'day13',
      date: 'Dom 28',
      title: 'Castillo + Umeda',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Osaka+Castle',
      activities: [
        { text: 'Castillo de Osaka (Tenshukaku) 9–17 h', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Osaka+Castle' },
        { text: 'Compras craft: Itoya Grand Front Osaka y Yuzawaya Umeda', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Grand+Front+Osaka' },
        { text: 'Mirador Umeda Sky Building (9:30–22:30)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Umeda+Sky+Building+Osaka' }
      ],
      city: 'Osaka'
    },
    {
      id: 'day14',
      date: 'Lun 29',
      title: 'Traslado a Tokio (Shinjuku)',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Hilton+Tokyo+Shinjuku',
      activities: [
        { text: 'Llegada al Hilton Tokyo', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Hilton+Tokyo+Shinjuku' },
        { text: 'Tarde-noche por Kabukichō / Shinjuku-Sanchōme', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Kabukicho+Shinjuku+Tokyo' }
      ],
      city: 'Tokyo'
    },
    {
      id: 'day15',
      date: 'Mar 30',
      title: 'Últimas compras + mirador',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Tokyo+Metropolitan+Government+Building',
      activities: [
        { text: 'Repesca en SEKAIDO', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Sekaido+Shinjuku+Tokyo' },
        { text: 'Mirador gratuito Tochō (Gobierno Metropolitano)', mapUrl: 'https://www.google.com/maps/search/?api=1&query=Tokyo+Metropolitan+Government+Building' },
        'Equipaje y cena final'
      ],
      city: 'Tokyo'
    },
    {
      id: 'day16',
      date: 'Mié 1 oct',
      title: 'Check-out y salida',
      mapUrl: 'https://www.google.com/maps/search/?api=1&query=Narita+Airport+Tokyo',
      activities: [
        'Traslado a aeropuerto'
      ],
      city: 'Tokyo'
    },
  ];

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      darkMode ? 'dark bg-gray-900 text-white' : 'bg-gradient-to-br from-red-50 to-pink-50 text-gray-900'
    }`}>
      {/* Header */}
      <header className={`sticky top-0 z-50 backdrop-blur-lg border-b transition-colors duration-300 ${
        darkMode ? 'bg-gray-900/90 border-gray-700' : 'bg-white/90 border-gray-200'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="text-2xl">🗾</div>
                <div>
                  <h1 className="text-xl font-bold">Japón 2025</h1>
                  <p className="text-xs text-gray-500">4 personas • 16 sep - 1 oct</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm">
                {isOnline ? (
                  <Wifi className="w-4 h-4 text-green-500" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-500" />
                )}
                <span className="hidden sm:inline">
                  {isOnline ? 'En línea' : 'Sin conexión'}
                </span>
              </div>
              
              <div className="flex items-center space-x-2 text-sm bg-gradient-to-r from-blue-500 to-purple-500 text-white px-3 py-1 rounded-full">
                <Calendar className="w-4 h-4" />
                <span>{daysUntilTrip > 0 ? `${daysUntilTrip} días restantes` : 'En viaje!'}</span>
              </div>
              
              <button
                onClick={() => setDarkMode(!darkMode)}
                className={`p-2 rounded-lg transition-colors ${
                  darkMode ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-200 hover:bg-gray-300'
                }`}
              >
                {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <nav className={`border-b transition-colors duration-300 ${
        darkMode ? 'border-gray-700 bg-gray-800' : 'border-gray-200 bg-white'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex space-x-8">
            {[
              { id: 'itinerary', name: 'Itinerario', icon: Calendar },
              { id: 'hotels', name: 'Hoteles', icon: MapPin },
              { id: 'shopping', name: 'Compras', icon: ShoppingCart },
              { id: 'budget', name: 'Presupuesto', icon: Wallet },
              { id: 'utils', name: 'Utilidades', icon: Settings }
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center space-x-2 py-4 border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? 'border-red-500 text-red-600'
                    : 'border-transparent hover:text-red-500'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                <span className="font-medium">{tab.name}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'itinerary' && (
          <div className="space-y-8">
            {/* Progress Overview */}
            <div className={`rounded-xl p-6 transition-colors ${
              darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'
            }`}>
              <h2 className="text-2xl font-bold mb-4 flex items-center">
                <Star className="w-6 h-6 mr-2 text-yellow-500" />
                Progreso del Viaje
                <div className="ml-auto flex items-center space-x-2 text-sm">
                  <div className="flex items-center space-x-2 bg-green-100 dark:bg-green-900/30 px-3 py-1 rounded-full">
                    <Clock className="w-4 h-4 text-green-600" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      España: {spainTime}
                    </span>
                  </div>
                    <Clock className="w-4 h-4 text-green-600" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      España: {spainTime}
                    </span>
                <div className="ml-auto flex items-center space-x-2 text-sm">
                  <div className="flex items-center space-x-2 bg-green-100 dark:bg-green-900/30 px-3 py-1 rounded-full">
                    <Clock className="w-4 h-4 text-green-600" />
                    <span className="font-medium text-green-800 dark:text-green-200">
                      España: {spainTime}
                    </span>
                  </div>
                    <Clock className="w-4 h-4 text-blue-600" />
                    <span className="font-medium text-blue-800 dark:text-blue-200">
                      Japón: {japanTime}
                    </span>
                  </div>
                </div>
              </h2>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {cities.map((city, index) => (
                  <div key={city.name} className={`p-4 rounded-lg bg-gradient-to-r ${city.color} text-white`}>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-semibold">{city.name}</h3>
                        <p className="text-sm opacity-90">{city.dates}</p>
                        {weatherLoading ? (
                          <div className="mt-2 text-sm opacity-75">
                            <div className="animate-pulse">Cargando clima...</div>
                          </div>
                        ) : city.weather && (
                          <div className="mt-2 space-y-1">
                            <div className="flex items-center text-sm">
                              <span className="mr-1">{city.weather.icon}</span>
                              <span>{city.weather.temp}°C</span>
                            </div>
                            <div className="flex items-center text-xs opacity-90">
                              <span className="mr-1">{city.weather.clothingIcon}</span>
                              <span className="truncate">{city.weather.clothingSuggestion}</span>
                            </div>
                          </div>
                        )}
                      </div>
                      <div className="text-right">
                        <Thermometer className="w-5 h-5 opacity-75" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Daily Itinerary */}
            <div className="space-y-6">
              <h2 className="text-2xl font-bold">Plan Día a Día</h2>
              {itineraryDays.map(day => (
                <div key={day.id} className={`rounded-xl p-6 transition-all duration-300 hover:shadow-lg ${
                  darkMode ? 'bg-gray-800' : 'bg-white shadow-md'
                }`}>
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-xl font-semibold text-red-600">{day.date}</h3>
                      <a 
                        href={day.mapUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-lg font-medium text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                      >
                        {day.title}
                      </a>
                      <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mt-2 ${
                        darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {day.city}
                      </span>
                    </div>
                    <button
                      onClick={() => togglePlace(day.id)}
                      className={`p-2 rounded-lg transition-all duration-300 ${
                        visitedPlaces[day.id]
                          ? 'bg-green-500 text-white scale-110'
                          : darkMode 
                            ? 'bg-gray-700 hover:bg-gray-600' 
                            : 'bg-gray-200 hover:bg-gray-300'
                      }`}
                    >
                      <Check className="w-5 h-5" />
                    </button>
                  </div>
                  
                  <div className="space-y-3">
                    {day.activities.map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3">
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                          darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
                        }`}>
                          {index + 1}
                        </div>
                        <div className="flex-1">
                          {typeof activity === 'string' ? (
                            <p>{activity}</p>
                          ) : (
                            <a 
                              href={activity.mapUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-800 hover:underline transition-colors"
                            >
                              {activity.text}
                            </a>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-4">
                    <textarea
                      placeholder="Notas personales del día..."
                      value={notes[day.id] || ''}
                      onChange={(e) => updateNote(day.id, e.target.value)}
                      className={`w-full p-3 rounded-lg border transition-colors resize-none ${
                        darkMode 
                          ? 'bg-gray-700 border-gray-600 text-white placeholder-gray-400' 
                          : 'bg-gray-50 border-gray-200 text-gray-900 placeholder-gray-500'
                      }`}
                      rows={3}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'hotels' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Hoteles y Ubicaciones</h2>
            <div className={`p-4 rounded-lg ${darkMode ? 'bg-gray-800' : 'bg-blue-50'}`}>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Clock className="w-5 h-5 text-blue-600" />
                  <span className="font-medium">Japón:</span>
                  <span className="font-bold text-blue-800 dark:text-blue-200">{japanTime}</span>
                </div>
                {!weatherLoading && (
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    Actualizado cada 10 min
                  </div>
                )}
              </div>
            </div>
            {cities.map((city, index) => (
              <div key={city.name} className={`rounded-xl p-6 transition-all hover:shadow-lg ${
                darkMode ? 'bg-gray-800' : 'bg-white shadow-md'
              }`}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <a 
                      href={city.hotelUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-xl font-semibold text-red-600 hover:text-red-800 hover:underline transition-colors"
                    >
                      {city.name}
                    </a>
                    <p className="text-gray-600 dark:text-gray-400 mb-2">{city.dates}</p>
                    <a 
                      href={city.hotelUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="font-medium mb-3 text-blue-600 hover:text-blue-800 hover:underline transition-colors block"
                    >
                      {city.hotel}
                    </a>
                    {weatherLoading ? (
                      <div className="mb-4 p-3 bg-gray-100 dark:bg-gray-700 rounded-lg animate-pulse">
                        <div className="text-sm text-gray-500">Cargando información meteorológica...</div>
                      </div>
                    ) : city.weather && (
                      <div className="mb-4 p-3 bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-lg">
                        <div className="flex items-start justify-between">
                          <div className="flex items-center space-x-3">
                            <span className="text-3xl">{city.weather.icon}</span>
                            <div>
                              <p className="font-semibold text-lg">{city.weather.temp}°C</p>
                              <p className="text-sm text-gray-600 dark:text-gray-400">{city.weather.condition}</p>
                              <p className="text-xs text-gray-500">Humedad: {city.weather.humidity}% • Viento: {city.weather.windSpeed} km/h</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center space-x-1 text-sm font-medium text-purple-700 dark:text-purple-300">
                              <Shirt className="w-4 h-4" />
                              <span>Ropa recomendada:</span>
                            </div>
                            <div className="flex items-center space-x-1 text-sm mt-1">
                              <span>{city.weather.clothingIcon}</span>
                              <span className="text-gray-600 dark:text-gray-400">{city.weather.clothingSuggestion}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex space-x-2">
                    <button className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                      <Navigation className="w-4 h-4" />
                      <span>Mapa</span>
                    </button>
                    <button className="flex items-center space-x-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
                      <ExternalLink className="w-4 h-4" />
                      <span>Hotel</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'shopping' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Lista de Compras</h2>
            
            {/* Add new item form */}
            <div className={`p-6 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'}`}>
              <h3 className="text-lg font-semibold mb-4">Añadir nuevo artículo</h3>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <input
                  type="text"
                  placeholder="Nombre del artículo"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  className={`p-3 border rounded-lg ${
                    darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                  }`}
                />
                <select
                  value={newItemCategory}
                  onChange={(e) => setNewItemCategory(e.target.value)}
                  className={`p-3 border rounded-lg ${
                    darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                  }`}
                >
                  <option value="Papelería">Papelería</option>
                  <option value="Menaje">Menaje</option>
                  <option value="Arte">Arte</option>
                  <option value="Craft">Craft</option>
                  <option value="Souvenirs">Souvenirs</option>
                  <option value="Ropa">Ropa</option>
                  <option value="Comida">Comida</option>
                  <option value="Otros">Otros</option>
                </select>
                <input
                  type="number"
                  placeholder="Precio estimado (¥)"
                  value={newItemPrice}
                  onChange={(e) => setNewItemPrice(e.target.value)}
                  className={`p-3 border rounded-lg ${
                    darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                  }`}
                />
                <button
                  onClick={addNewItem}
                  className="px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors font-medium"
                >
                  Añadir
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 space-y-4">
                {purchaseList.length === 0 && (
                  <div className={`p-8 text-center rounded-lg border-2 border-dashed ${
                    darkMode ? 'border-gray-600 text-gray-400' : 'border-gray-300 text-gray-500'
                  }`}>
                    <ShoppingCart className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No hay artículos en tu lista de compras</p>
                    <p className="text-sm">Añade algunos artículos que quieras comprar en Japón</p>
                  </div>
                )}
                {purchaseList.map(item => (
                  <div key={item.id} className={`p-4 rounded-lg border transition-all ${
                    item.purchased 
                      ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-700' 
                      : darkMode 
                        ? 'bg-gray-800 border-gray-700' 
                        : 'bg-white border-gray-200'
                  }`}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <button
                          onClick={() => togglePurchase(item.id)}
                          className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                            item.purchased
                              ? 'bg-green-500 border-green-500 text-white'
                              : 'border-gray-300 hover:border-green-500'
                          }`}
                        >
                          {item.purchased && <Check className="w-4 h-4" />}
                        </button>
                        <div>
                          <h3 className={`font-medium ${item.purchased ? 'line-through opacity-60' : ''}`}>
                            {item.name}
                          </h3>
                          <p className="text-sm text-gray-500">{item.category}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="text-right">
                          <p className="font-semibold">¥{item.estimated_price.toLocaleString()}</p>
                          <p className="text-xs text-gray-500">~€{(item.estimated_price / exchangeRate).toFixed(2)}</p>
                          {item.purchased && item.actual_price && item.actual_price !== item.estimated_price && (
                            <div>
                              <p className="text-xs text-green-600">Real: ¥{item.actual_price.toLocaleString()}</p>
                              <p className="text-xs text-green-600">~€{(item.actual_price / exchangeRate).toFixed(2)}</p>
                            </div>
                          )}
                        </div>
                        <button
                          onClick={() => removeItem(item.id)}
                          className="p-1 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition-colors"
                        >
                          <span className="text-lg">×</span>
                        </button>
                      </div>
                    </div>
                    {item.purchased && (
                      <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-600">
                        <div className="flex items-center space-x-3">
                          <input
                            type="number"
                            placeholder="Precio real pagado"
                            onChange={(e) => updateItemPrice(item.id, parseInt(e.target.value) || item.estimated_price)}
                            className={`flex-1 p-2 text-sm border rounded ${
                              darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                            }`}
                          />
                          <input
                            type="text"
                            placeholder="¿Dónde lo compraste?"
                            className={`flex-1 p-2 text-sm border rounded ${
                              darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                            }`}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              <div className={`p-6 rounded-xl h-fit sticky top-24 ${
                darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'
              }`}>
                <h3 className="text-lg font-semibold mb-4">Resumen de Compras</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span>Presupuesto:</span>
                    <div className="text-right">
                      <span className="font-semibold">¥{shoppingBudget.toLocaleString()}</span>
                      <p className="text-xs text-gray-500">~€{(shoppingBudget / exchangeRate).toFixed(2)}</p>
                    </div>
                  </div>
                  <div className="flex justify-between">
                    <span>Gastado:</span>
                    <div className="text-right">
                      <span className="font-semibold text-green-600">¥{shoppingSpent.toLocaleString()}</span>
                      <p className="text-xs text-gray-500">~€{(shoppingSpent / exchangeRate).toFixed(2)}</p>
                    </div>
                  </div>
                  <div className="flex justify-between border-t pt-3">
                    <span>Restante:</span>
                    <div className="text-right">
                      <span className="font-semibold">¥{(shoppingBudget - shoppingSpent).toLocaleString()}</span>
                      <p className="text-xs text-gray-500">~€{((shoppingBudget - shoppingSpent) / exchangeRate).toFixed(2)}</p>
                    </div>
                  </div>
                  <div className={`w-full rounded-full h-2 ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
                    <div 
                      className="h-2 bg-gradient-to-r from-green-400 to-green-600 rounded-full transition-all duration-300"
                      style={{width: `${shoppingBudget > 0 ? (shoppingSpent / shoppingBudget) * 100 : 0}%`}}
                    />
                  </div>
                  <p className="text-xs text-center text-gray-500">
                    {shoppingBudget > 0 ? Math.round((shoppingSpent / shoppingBudget) * 100) : 0}% gastado
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'budget' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Gestión de Presupuesto del Viaje</h2>
            
            {/* Gastos ya pagados */}
            <div className={`p-6 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'}`}>
              <h3 className="text-lg font-semibold mb-4 text-green-600">✅ Gastos ya pagados</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Plane className="w-5 h-5 text-green-600" />
                    <span>Vuelos</span>
                  </div>
                  <span className="font-semibold">€1,200</span>
                </div>
                <div className="flex justify-between items-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-5 h-5 text-green-600" />
                    <span>Hoteles</span>
                  </div>
                  <span className="font-semibold">€800</span>
                </div>
              </div>
            </div>

            {/* Presupuesto del viaje */}
            <div className={`p-6 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'}`}>
              <h3 className="text-lg font-semibold mb-4">💰 Presupuesto para gastos del viaje</h3>
              <div className="space-y-4">
                {budgetCategories.map(category => (
                  <div key={category.id} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium">{category.name}</span>
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateBudgetSpent(category.id, -1000)}
                            className="w-8 h-8 bg-red-500 text-white rounded-full text-sm hover:bg-red-600 transition-colors flex items-center justify-center"
                          >
                            -
                          </button>
                          <div className="text-sm min-w-[140px] text-center">
                            <div>¥{category.spent.toLocaleString()} / ¥{category.budgeted.toLocaleString()}</div>
                            <div className="text-xs text-gray-500">€{(category.spent / exchangeRate).toFixed(0)} / €{(category.budgeted / exchangeRate).toFixed(0)}</div>
                          </div>
                          <button
                            onClick={() => updateBudgetSpent(category.id, 1000)}
                            className="w-8 h-8 bg-green-500 text-white rounded-full text-sm hover:bg-green-600 transition-colors flex items-center justify-center"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>
                    <div className={`w-full rounded-full h-2 ${darkMode ? 'bg-gray-700' : 'bg-gray-200'}`}>
                      <div 
                        className={`h-2 bg-gradient-to-r ${category.color} rounded-full transition-all duration-300`}
                        style={{width: `${Math.min((category.spent / category.budgeted) * 100, 100)}%`}}
                      />
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-600">
                <div className="flex justify-between items-center text-lg font-semibold">
                  <span>Total presupuesto viaje:</span>
                  <div className="text-right">
                    <div>¥{totalBudget.toLocaleString()}</div>
                    <div className="text-sm text-gray-500 font-normal">~€{Math.round(totalBudget / exchangeRate)}</div>
                  </div>
                </div>
                <div className="flex justify-between items-center text-lg font-semibold text-red-600">
                  <span>Total gastado:</span>
                  <div className="text-right">
                    <div>¥{totalSpent.toLocaleString()}</div>
                    <div className="text-sm text-gray-500 font-normal">~€{Math.round(totalSpent / exchangeRate)}</div>
                  </div>
                </div>
                <div className="flex justify-between items-center text-lg font-semibold text-green-600">
                  <span>Restante:</span>
                  <div className="text-right">
                    <div>¥{(totalBudget - totalSpent).toLocaleString()}</div>
                    <div className="text-sm text-gray-500 font-normal">~€{Math.round((totalBudget - totalSpent) / exchangeRate)}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'utils' && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Utilidades de Viaje</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className={`p-6 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'}`}>
                <h3 className="text-lg font-semibold mb-4">Conversor de Moneda</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Yenes (¥)</label>
                    <input 
                      type="number" 
                      value={yenAmount}
                      onChange={(e) => convertYenToEuro(e.target.value)}
                      className={`w-full p-3 border rounded-lg ${
                        darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                      }`}
                    />
                  </div>
                  <div className="text-center">
                    <span className="text-2xl">⇅</span>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Euros (€)</label>
                    <input 
                      type="number" 
                      value={euroAmount}
                      onChange={(e) => convertEuroToYen(e.target.value)}
                      className={`w-full p-3 border rounded-lg ${
                        darkMode ? 'bg-gray-700 border-gray-600 text-white' : 'bg-gray-50 border-gray-300'
                      }`}
                    />
                  </div>
                  <p className="text-xs text-gray-500 text-center">1 EUR ≈ {exchangeRate} JPY (aproximado)</p>
                </div>
              </div>
              
              <div className={`p-6 rounded-xl ${darkMode ? 'bg-gray-800' : 'bg-white shadow-lg'}`}>
                <h3 className="text-lg font-semibold mb-4">Frases Útiles</h3>
                <div className="space-y-3">
                  <div className="p-3 bg-gradient-to-r from-red-100 to-pink-100 dark:from-red-900/20 dark:to-pink-900/20 rounded-lg">
                    <p className="font-medium">こんにちは (Konnichiwa)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Hola / Buenas tardes</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-blue-100 to-purple-100 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg">
                    <p className="font-medium">ありがとうございます (Arigatou gozaimasu)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Muchas gracias</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-green-100 to-teal-100 dark:from-green-900/20 dark:to-teal-900/20 rounded-lg">
                    <p className="font-medium">すみません (Sumimasen)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Disculpe / Perdón</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-yellow-100 to-orange-100 dark:from-yellow-900/20 dark:to-orange-900/20 rounded-lg">
                    <p className="font-medium">いくらですか？ (Ikura desu ka?)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">¿Cuánto cuesta?</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-indigo-100 to-blue-100 dark:from-indigo-900/20 dark:to-blue-900/20 rounded-lg">
                    <p className="font-medium">...はどこですか？ (...wa doko desu ka?)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">¿Dónde está...?</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-teal-100 to-green-100 dark:from-teal-900/20 dark:to-green-900/20 rounded-lg">
                    <p className="font-medium">...にどうやって行きますか？ (...ni dou yatte ikimasu ka?)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">¿Cómo llego a...?</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-900/20 dark:to-pink-900/20 rounded-lg">
                    <p className="font-medium">英語を話せますか？ (Eigo wo hanasemasu ka?)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">¿Habla inglés?</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-rose-100 to-red-100 dark:from-rose-900/20 dark:to-red-900/20 rounded-lg">
                    <p className="font-medium">助けてください (Tasukete kudasai)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Ayúdeme, por favor</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-cyan-100 to-blue-100 dark:from-cyan-900/20 dark:to-blue-900/20 rounded-lg">
                    <p className="font-medium">写真を撮ってもらえますか？ (Shashin wo totte moraemasu ka?)</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">¿Puede tomarme una foto?</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;